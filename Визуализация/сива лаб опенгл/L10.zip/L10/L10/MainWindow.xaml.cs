﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Media.Media3D;
using System.Drawing;

namespace L10
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        GeometryModel3D mGeometry;
        bool mDown;
        Point mLastPos;

        public MainWindow()
        {
            InitializeComponent();

            // Define 3D mesh object
            MeshGeometry3D mesh = new MeshGeometry3D();

            //mesh.Positions.Add(new Point3D(-1, -1, 1));
            //mesh.Positions.Add(new Point3D(1, -1, 1));
            //mesh.Positions.Add(new Point3D(1, 1, 1));
            //mesh.Positions.Add(new Point3D(-1, 1, 1));

            mesh.Positions.Add(new Point3D(0, -0.14, 1.4));         //Center    0
            mesh.Positions.Add(new Point3D(1.2, 0.3, 1));           //A         1
            mesh.Positions.Add(new Point3D(0.33, 0.33, 1));         //B         2
            mesh.Positions.Add(new Point3D(0, 1.2, 1));             //C         3
            mesh.Positions.Add(new Point3D(-0.33, 0.33, 1));        //D         4
            mesh.Positions.Add(new Point3D(-1.2, 0.3, 1));          //E         5
            mesh.Positions.Add(new Point3D(-0.54, -0.25, 1));       //F         6
            mesh.Positions.Add(new Point3D(-0.77, -1.1, 1));        //G         7
            mesh.Positions.Add(new Point3D(0, -0.66, 1));           //H         8
            mesh.Positions.Add(new Point3D(0.77, -1.1, 1));         //I         9
            mesh.Positions.Add(new Point3D(0.54, -0.25, 1));        //Y         10

            mesh.Positions.Add(new Point3D(0, -0.14, 0.6));         //-Center   11


            // first triangle
            mesh.TriangleIndices.Add(0);
            mesh.TriangleIndices.Add(1);
            mesh.TriangleIndices.Add(2);
            //second triangle
            mesh.TriangleIndices.Add(0);
            mesh.TriangleIndices.Add(2);
            mesh.TriangleIndices.Add(3);
            // 3rd
            mesh.TriangleIndices.Add(0);
            mesh.TriangleIndices.Add(3);
            mesh.TriangleIndices.Add(4);
            // 4rd
            mesh.TriangleIndices.Add(0);
            mesh.TriangleIndices.Add(4);
            mesh.TriangleIndices.Add(5);
            // 5th
            mesh.TriangleIndices.Add(0);
            mesh.TriangleIndices.Add(5);
            mesh.TriangleIndices.Add(6);
            // 6th
            mesh.TriangleIndices.Add(0);
            mesh.TriangleIndices.Add(6);
            mesh.TriangleIndices.Add(7);
            // 7th
            mesh.TriangleIndices.Add(0);
            mesh.TriangleIndices.Add(7);
            mesh.TriangleIndices.Add(8);
            // 8th
            mesh.TriangleIndices.Add(0);
            mesh.TriangleIndices.Add(8);
            mesh.TriangleIndices.Add(9);
            // 9th
            mesh.TriangleIndices.Add(0);
            mesh.TriangleIndices.Add(9);
            mesh.TriangleIndices.Add(10);
            // 10th
            mesh.TriangleIndices.Add(0);
            mesh.TriangleIndices.Add(10);
            mesh.TriangleIndices.Add(1);


            //back edges
            // first triangle
            mesh.TriangleIndices.Add(2);
            mesh.TriangleIndices.Add(1);
            mesh.TriangleIndices.Add(11);
            //second triangle
            mesh.TriangleIndices.Add(3);
            mesh.TriangleIndices.Add(2);
            mesh.TriangleIndices.Add(11);
            // 3rd
            mesh.TriangleIndices.Add(4);
            mesh.TriangleIndices.Add(3);
            mesh.TriangleIndices.Add(11);
            // 4rd
            mesh.TriangleIndices.Add(5);
            mesh.TriangleIndices.Add(4);
            mesh.TriangleIndices.Add(11);
            // 5th
            mesh.TriangleIndices.Add(6);
            mesh.TriangleIndices.Add(5);
            mesh.TriangleIndices.Add(11);
            // 6th
            mesh.TriangleIndices.Add(7);
            mesh.TriangleIndices.Add(6);
            mesh.TriangleIndices.Add(11);
            // 7th
            mesh.TriangleIndices.Add(8);
            mesh.TriangleIndices.Add(7);
            mesh.TriangleIndices.Add(11);
            // 8th
            mesh.TriangleIndices.Add(9);
            mesh.TriangleIndices.Add(8);
            mesh.TriangleIndices.Add(11);
            // 9th
            mesh.TriangleIndices.Add(10);
            mesh.TriangleIndices.Add(9);
            mesh.TriangleIndices.Add(11);
            // 10th
            mesh.TriangleIndices.Add(1);
            mesh.TriangleIndices.Add(10);
            mesh.TriangleIndices.Add(11);
            

            //ImageBrush myBrush = new ImageBrush(new BitmapImage(new Uri(@"C:\Users\fw_sa\Downloads\визуальное\L10\L10\forBrush.jpg")));

            mGeometry = new GeometryModel3D(mesh, new DiffuseMaterial(Brushes.Red));
            //mGeometry = new GeometryModel3D(mesh, new SpecularMaterial(Brushes.DarkRed, 1));
            mGeometry.Transform = new Transform3DGroup();
            group.Children.Add(mGeometry);

    }

        private void Grid_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            camera.Position = new Point3D(
                camera.Position.X,
                camera.Position.Y,
                camera.Position.Z - e.Delta / 250D);
        }

        //private void Button_Click(object sender, RoutedEventArgs e)
        //{
        //    camera.Position = new Point3D(
        //        camera.Position.X,
        //            camera.Position.Y, 5);
        //}
        private void Grid_MouseUp(object sender, MouseButtonEventArgs e)
        {
            mDown = false;
        }

        private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton != MouseButtonState.Pressed) return;
            mDown = true;
            Point pos = Mouse.GetPosition(viewport);
            mLastPos = new Point(
                    pos.X - viewport.ActualWidth / 2,
                    viewport.ActualHeight / 2 - pos.Y);
        }
        private void Grid_MouseMove(object sender, MouseEventArgs e)
        {
            if (!mDown) return;
            Point pos = Mouse.GetPosition(viewport);
            Point actualPos = new Point(
                    pos.X - viewport.ActualWidth / 2,
                    viewport.ActualHeight / 2 - pos.Y);
            double dx = actualPos.X - mLastPos.X;
            double dy = actualPos.Y - mLastPos.Y;
            double mouseAngle = 0;

            if (dx != 0 && dy != 0)
            {
                mouseAngle = Math.Asin(Math.Abs(dy) /
                    Math.Sqrt(Math.Pow(dx, 2) + Math.Pow(dy, 2)));
                if (dx < 0 && dy > 0) mouseAngle += Math.PI / 2;
                else if (dx < 0 && dy < 0) mouseAngle += Math.PI;
                else if (dx > 0 && dy < 0) mouseAngle += Math.PI * 1.5;
            }
            else if (dx == 0 && dy != 0)
            {
                mouseAngle = Math.Sign(dy) > 0 ? Math.PI / 2 : Math.PI * 1.5;
            }
            else if (dx != 0 && dy == 0)
            {
                mouseAngle = Math.Sign(dx) > 0 ? 0 : Math.PI;
            }

            double axisAngle = mouseAngle + Math.PI / 2;

            Vector3D axis = new Vector3D(
                    Math.Cos(axisAngle) * 4,
                    Math.Sin(axisAngle) * 4, 0);

            double rotation = 0.02 *
                    Math.Sqrt(Math.Pow(dx, 2) + Math.Pow(dy, 2));

            Transform3DGroup group = mGeometry.Transform as Transform3DGroup;
            QuaternionRotation3D r =
                 new QuaternionRotation3D(
                 new Quaternion(axis, rotation * 180 / Math.PI));
            group.Children.Add(new RotateTransform3D(r));

            mLastPos = actualPos;
        }
    }
}
